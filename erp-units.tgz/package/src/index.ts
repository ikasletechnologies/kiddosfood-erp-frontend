import { Decimal } from 'decimal.js';

export type UnitDimension = 'WEIGHT' | 'VOLUME' | 'COUNT';

export const UNITS = {
  // WEIGHT
  MG: { dimension: 'WEIGHT', canonical: 'G', multiplierToCanonical: '0.001' },
  G: { dimension: 'WEIGHT', canonical: 'G', multiplierToCanonical: '1' },
  KG: { dimension: 'WEIGHT', canonical: 'G', multiplierToCanonical: '1000' },
  
  // VOLUME
  ML: { dimension: 'VOLUME', canonical: 'ML', multiplierToCanonical: '1' },
  L: { dimension: 'VOLUME', canonical: 'ML', multiplierToCanonical: '1000' },
  
  // COUNT (No global multipliers between them)
  PCS: { dimension: 'COUNT', canonical: 'PCS', multiplierToCanonical: '1' },
  BOX: { dimension: 'COUNT', canonical: 'BOX', multiplierToCanonical: '1' },
  PACK: { dimension: 'COUNT', canonical: 'PACK', multiplierToCanonical: '1' },
  BAG: { dimension: 'COUNT', canonical: 'BAG', multiplierToCanonical: '1' },
  BOTTLE: { dimension: 'COUNT', canonical: 'BOTTLE', multiplierToCanonical: '1' },
} as const;

export type ValidUnit = keyof typeof UNITS;

/**
 * Normalizes a weight or volume measurement to its global canonical base.
 * @param quantity The transaction quantity
 * @param unit The unit of the transaction quantity
 * @returns The normalized quantity in the canonical unit (e.g., G for weight, ML for volume)
 */
export function normalizeMeasurement(quantity: number | string | Decimal, unit: ValidUnit): Decimal {
  const unitConfig = UNITS[unit];
  if (!unitConfig) {
    throw new Error(`Unknown unit: ${unit}`);
  }
  
  if (unitConfig.dimension === 'COUNT') {
    // Counts do not automatically normalize to PCS without a product multiplier.
    // They remain in their exact unit config mathematically, just returning the same amount.
    return new Decimal(quantity);
  }

  return new Decimal(quantity).mul(unitConfig.multiplierToCanonical);
}

/**
 * Converts a quantity from one unit to another, strictly within the same dimension.
 * Used primarily by formatQuantity or explicit UI conversions.
 */
export function convertMeasurement(quantity: number | string | Decimal, fromUnit: ValidUnit, toUnit: ValidUnit): Decimal {
  const fromConfig = UNITS[fromUnit];
  const toConfig = UNITS[toUnit];

  if (!fromConfig || !toConfig) {
    throw new Error(`Unknown unit: ${fromUnit} or ${toUnit}`);
  }

  if (fromConfig.dimension !== toConfig.dimension) {
    throw new Error(`Incompatible units: Cannot convert ${fromUnit} (${fromConfig.dimension}) to ${toUnit} (${toConfig.dimension})`);
  }

  if (fromConfig.dimension === 'COUNT' && fromUnit !== toUnit) {
    throw new Error(`Invalid conversion: Cannot automatically convert COUNT units (${fromUnit} to ${toUnit}) without product-specific packaging multipliers.`);
  }

  // Convert to canonical first, then divide by the target's canonical multiplier
  const canonicalQty = new Decimal(quantity).mul(fromConfig.multiplierToCanonical);
  return canonicalQty.div(toConfig.multiplierToCanonical);
}

/**
 * Safely converts count/packaging units strictly using a product-specific multiplier.
 * e.g., 5 BOX -> 120 PCS (if 1 BOX = 24 PCS).
 */
export function convertPackaging(
  quantity: number | string | Decimal, 
  fromUnit: ValidUnit, 
  toUnit: ValidUnit, 
  productConversionMultiplier: number | string | Decimal
): Decimal {
  const fromConfig = UNITS[fromUnit];
  const toConfig = UNITS[toUnit];

  if (fromConfig?.dimension !== 'COUNT' || toConfig?.dimension !== 'COUNT') {
    throw new Error(`convertPackaging is strictly for COUNT dimension. Received ${fromUnit} and ${toUnit}.`);
  }

  return new Decimal(quantity).mul(productConversionMultiplier);
}

/**
 * Formats a given normalized quantity into a preferred display unit and appends the unit suffix.
 * e.g., formatQuantity(8000, "G", "KG") -> "8.00 KG"
 * e.g., formatQuantity(8000, "G", "G") -> "8000 G"
 */
export function formatQuantity(normalizedQuantity: number | string | Decimal, canonicalUnit: ValidUnit, preferredDisplayUnit: ValidUnit): string {
  if (canonicalUnit === preferredDisplayUnit) {
    return `${new Decimal(normalizedQuantity).toString()} ${preferredDisplayUnit}`;
  }

  const converted = convertMeasurement(normalizedQuantity, canonicalUnit, preferredDisplayUnit);
  
  // Format with up to 2 decimal places if it has fractional parts, otherwise just the whole number.
  // Using toDecimalPlaces(2) instead of toFixed(2) handles trailing zeros optionally, but for UI
  // the user specifically used "8.00 KG".
  return `${converted.toFixed(2)} ${preferredDisplayUnit}`;
}
