import { Decimal } from 'decimal.js';
import { normalizeMeasurement, convertMeasurement, convertPackaging, formatQuantity } from '../src/index';

describe('Unit Conversion Engine', () => {

  describe('normalizeMeasurement', () => {
    it('normalizes weight correctly to canonical G', () => {
      expect(normalizeMeasurement(10, 'KG').toNumber()).toBe(10000);
      expect(normalizeMeasurement(500, 'G').toNumber()).toBe(500);
      expect(normalizeMeasurement(1, 'MG').toNumber()).toBe(0.001);
    });

    it('normalizes volume correctly to canonical ML', () => {
      expect(normalizeMeasurement(10, 'L').toNumber()).toBe(10000);
      expect(normalizeMeasurement(500, 'ML').toNumber()).toBe(500);
    });

    it('returns exact same amount for COUNT dimension (does not normalize to PCS without product multiplier)', () => {
      expect(normalizeMeasurement(5, 'BOX').toNumber()).toBe(5);
      expect(normalizeMeasurement(10, 'PCS').toNumber()).toBe(10);
    });
  });

  describe('convertMeasurement', () => {
    it('converts within the same dimension', () => {
      expect(convertMeasurement(10000, 'G', 'KG').toNumber()).toBe(10);
      expect(convertMeasurement(10, 'KG', 'G').toNumber()).toBe(10000);
      expect(convertMeasurement(10, 'L', 'ML').toNumber()).toBe(10000);
    });

    it('rejects cross-dimension conversions', () => {
      expect(() => convertMeasurement(10, 'KG', 'L')).toThrow('Incompatible units');
      expect(() => convertMeasurement(10, 'G', 'ML')).toThrow('Incompatible units');
      expect(() => convertMeasurement(10, 'PCS', 'KG')).toThrow('Incompatible units');
    });

    it('rejects count-to-count automatic conversions without multiplier', () => {
      expect(() => convertMeasurement(5, 'BOX', 'PCS')).toThrow('Cannot automatically convert COUNT units');
    });
  });

  describe('convertPackaging', () => {
    it('applies product-specific multipliers correctly for counts', () => {
      // 5 BOX -> 120 PCS (multiplier: 24)
      expect(convertPackaging(5, 'BOX', 'PCS', 24).toNumber()).toBe(120);
    });

    it('rejects non-COUNT dimensions', () => {
      expect(() => convertPackaging(5, 'KG', 'G', 1000)).toThrow('strictly for COUNT dimension');
    });
  });

  describe('formatQuantity', () => {
    it('formats display strings using specified display unit', () => {
      // 8000 G -> 8.00 KG
      expect(formatQuantity(8000, 'G', 'KG')).toBe('8.00 KG');
      
      // 500 G -> 500 G
      expect(formatQuantity(500, 'G', 'G')).toBe('500 G');
      
      // 10000 ML -> 10.00 L
      expect(formatQuantity(10000, 'ML', 'L')).toBe('10.00 L');
    });
  });

  describe('Decimal precision', () => {
    it('does not suffer from floating point errors', () => {
      // 0.1 + 0.2 floating point typically is 0.30000000000000004
      // Let's simulate a similar conversion: 0.1 KG -> 100 G, 0.2 KG -> 200 G.
      const q1 = normalizeMeasurement('0.1', 'KG');
      const q2 = normalizeMeasurement('0.2', 'KG');
      const sum = q1.plus(q2);
      expect(sum.toNumber()).toBe(300); // 300 G exact.
    });
  });
});
